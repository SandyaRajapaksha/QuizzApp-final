package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Quiz;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageView myimage3 = findViewById(R.id.myimage3);
        myimage3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, detailActivity2.class);
                startActivity(intent);
            }
        });
        ImageView myimage1 = findViewById(R.id.myimage1);
        myimage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, detailActivity2.class);
                startActivity(intent);
            }
        });
        ImageView myimage2 = findViewById(R.id.myimage2);
        myimage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, detailActivity2.class);
                startActivity(intent);
            }
        });
        ImageView myimage = findViewById(R.id.myimage);
        myimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, detailActivity2.class);
                startActivity(intent);
            }
        });
        ImageView addCategory = findViewById(R.id.addCategory);
        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(home.this, add_catagory.class);
                startActivity(intent);
            }
        });
    }
}
